# TCS Synthetic Company Knowledge Base - 2026

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Snapshot: 2026-11-02

## What is TCS?
TCS - Technology Consulting Sandbox is a fictional IT services company, not Tata Consultancy Services. It has 80 employees across 8 departments in Europe and the Americas.

## How is reporting structured?
Every employee has one direct line manager. Managers in Cloud Engineering, Data & AI, Cybersecurity, Application Modernization, Enterprise Integrations, Quality Engineering, and Managed IT Operations report to Eleanor Hart (TCS-001). Eleanor reports to an external board. For exact line reporting use Employee_Directory_2026-11-02.csv or each employee profile.

## What role levels exist?
Intern: <1 year. Associate Engineer: 1 to <2. Mid-Senior Engineer: 2 to 5 inclusive. Senior Engineer: >5 to <9. Team Lead: 9 to 10 inclusive. Manager: >10 years. See HR-002 v2.0.

## What is the current remote policy?
As of November 2026, HR-001 v2.1 permits up to 3 remote days per week with line-manager approval. In 2025 HR-001 v1.0 permitted 2 days, and that version is archived.

## What did TCS earn in FY2025?
FY2025 revenue USD 18.4m; operating expenses USD 14.9m; operating profit USD 3.5m; income-tax provision USD 0.875m; net profit USD 2.625m.

## What is the security incident deadline?
Report a suspected security incident to Security Operations within 30 minutes after detection (IT-SEC-002). The separate client Sev1 acknowledgement target is 15 minutes (OPS-003).

## Who is the Finance Controller?
Marco Bellini (TCS-003) is Senior Finance Controller; line manager Priya Menon (TCS-002); ultimate senior employee Eleanor Hart (TCS-001).

All data is fake; do not use for actual business operations.
