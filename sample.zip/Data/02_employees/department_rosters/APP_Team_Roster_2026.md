# Application Modernization - Staff Roster

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Snapshot: 2026-11-02; department cost center: APP; headcount: 10.

| ID | Employee | Grade | Job title | Reports to | Office |
|---|---|---|---|---|---|
| TCS-041 | Clara Hoffmann | Manager | Application Modernization Manager | Eleanor Hart (TCS-001) | Berlin |
| TCS-042 | Vikram Sethi | Team Lead | Application Development Team Lead | Clara Hoffmann (TCS-041) | Berlin |
| TCS-043 | Rafael Mendes | Senior Engineer | Senior Backend Engineer | Vikram Sethi (TCS-042) | Berlin |
| TCS-044 | Julia Fischer | Senior Engineer | Senior Full-Stack Engineer | Vikram Sethi (TCS-042) | Austin |
| TCS-045 | Ava Robinson | Mid-Senior Engineer | Java Backend Engineer | Rafael Mendes (TCS-043) | Austin |
| TCS-046 | Omar Farouk | Mid-Senior Engineer | Frontend Engineer | Julia Fischer (TCS-044) | Austin |
| TCS-047 | Mei Chen | Mid-Senior Engineer | API Engineer | Rafael Mendes (TCS-043) | Paris |
| TCS-048 | Liam Collins | Associate Engineer | Application Engineer | Ava Robinson (TCS-045) | Paris |
| TCS-049 | Nora Schmidt | Associate Engineer | Software Associate | Omar Farouk (TCS-046) | Toronto |
| TCS-050 | Iris Taylor | Intern | Software Engineering Intern | Vikram Sethi (TCS-042) | Toronto |

The table is authoritative for line reporting as of the snapshot date.
