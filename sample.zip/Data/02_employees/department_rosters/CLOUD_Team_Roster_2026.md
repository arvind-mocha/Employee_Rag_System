# Cloud Engineering - Staff Roster

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Snapshot: 2026-11-02; department cost center: CLOUD; headcount: 10.

| ID | Employee | Grade | Job title | Reports to | Office |
|---|---|---|---|---|---|
| TCS-011 | Oliver Grant | Manager | Cloud Engineering Manager | Eleanor Hart (TCS-001) | London |
| TCS-012 | Anika Rao | Team Lead | Cloud Platform Team Lead | Oliver Grant (TCS-011) | London |
| TCS-013 | Lukas Weber | Senior Engineer | Senior Cloud Architect | Anika Rao (TCS-012) | London |
| TCS-014 | Emily Brooks | Senior Engineer | Senior Site Reliability Engineer | Anika Rao (TCS-012) | London |
| TCS-015 | Rohan Iyer | Mid-Senior Engineer | Cloud Engineer | Lukas Weber (TCS-013) | Berlin |
| TCS-016 | Isabelle Martin | Mid-Senior Engineer | DevOps Engineer | Emily Brooks (TCS-014) | Berlin |
| TCS-017 | Mateo Silva | Mid-Senior Engineer | Platform Engineer | Lukas Weber (TCS-013) | Toronto |
| TCS-018 | Leah Foster | Associate Engineer | Cloud Operations Associate | Rohan Iyer (TCS-015) | Toronto |
| TCS-019 | Ethan Reed | Associate Engineer | Infrastructure Associate | Isabelle Martin (TCS-016) | Austin |
| TCS-020 | Zoya Khan | Intern | Cloud Engineering Intern | Anika Rao (TCS-012) | Austin |

The table is authoritative for line reporting as of the snapshot date.
