# Executive & Corporate Services - Staff Roster

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Snapshot: 2026-11-02; department cost center: CORP; headcount: 10.

| ID | Employee | Grade | Job title | Reports to | Office |
|---|---|---|---|---|---|
| TCS-001 | Eleanor Hart | Manager | Managing Director | Board of Directors (external) (Board of Directors (external; no employee ID)) | London |
| TCS-002 | Priya Menon | Team Lead | People & Finance Team Lead | Eleanor Hart (TCS-001) | London |
| TCS-003 | Marco Bellini | Senior Engineer | Senior Finance Controller | Priya Menon (TCS-002) | London |
| TCS-004 | Sophie Laurent | Senior Engineer | Senior HR Business Partner | Priya Menon (TCS-002) | London |
| TCS-005 | Daniel Cho | Mid-Senior Engineer | Finance Analyst | Marco Bellini (TCS-003) | London |
| TCS-006 | Amira Hassan | Mid-Senior Engineer | Talent Operations Analyst | Sophie Laurent (TCS-004) | Toronto |
| TCS-007 | James Whitfield | Mid-Senior Engineer | Compliance Analyst | Marco Bellini (TCS-003) | Toronto |
| TCS-008 | Lucia Romero | Associate Engineer | HR Coordinator | Daniel Cho (TCS-005) | Toronto |
| TCS-009 | Noah Fischer | Associate Engineer | Accounts Assistant | Amira Hassan (TCS-006) | New York |
| TCS-010 | Maya Patel | Intern | People Operations Intern | Priya Menon (TCS-002) | New York |

The table is authoritative for line reporting as of the snapshot date.
