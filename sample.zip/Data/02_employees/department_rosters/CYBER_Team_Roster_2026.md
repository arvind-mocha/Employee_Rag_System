# Cybersecurity - Staff Roster

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Snapshot: 2026-11-02; department cost center: CYBER; headcount: 10.

| ID | Employee | Grade | Job title | Reports to | Office |
|---|---|---|---|---|---|
| TCS-031 | Gabriel Novak | Manager | Cybersecurity Manager | Eleanor Hart (TCS-001) | Amsterdam |
| TCS-032 | Fatima Saeed | Team Lead | Security Operations Team Lead | Gabriel Novak (TCS-031) | Amsterdam |
| TCS-033 | Charlotte Evans | Senior Engineer | Senior Security Architect | Fatima Saeed (TCS-032) | Amsterdam |
| TCS-034 | Kenji Watanabe | Senior Engineer | Senior Incident Responder | Fatima Saeed (TCS-032) | London |
| TCS-035 | Adrian Flores | Mid-Senior Engineer | Cloud Security Engineer | Charlotte Evans (TCS-033) | London |
| TCS-036 | Elena Petrova | Mid-Senior Engineer | Risk & Compliance Engineer | Kenji Watanabe (TCS-034) | Austin |
| TCS-037 | Samir Shah | Mid-Senior Engineer | IAM Engineer | Charlotte Evans (TCS-033) | Austin |
| TCS-038 | Grace Liu | Associate Engineer | SOC Analyst | Adrian Flores (TCS-035) | Austin |
| TCS-039 | Mila Torres | Associate Engineer | Security Operations Associate | Elena Petrova (TCS-036) | Toronto |
| TCS-040 | Leo Dupont | Intern | Security Intern | Fatima Saeed (TCS-032) | Toronto |

The table is authoritative for line reporting as of the snapshot date.
