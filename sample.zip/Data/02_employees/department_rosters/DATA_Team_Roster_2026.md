# Data & AI - Staff Roster

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Snapshot: 2026-11-02; department cost center: DATA; headcount: 10.

| ID | Employee | Grade | Job title | Reports to | Office |
|---|---|---|---|---|---|
| TCS-021 | Sofia Bennett | Manager | Data & AI Manager | Eleanor Hart (TCS-001) | New York |
| TCS-022 | Arjun Nair | Team Lead | Data Engineering Team Lead | Sofia Bennett (TCS-021) | New York |
| TCS-023 | Hannah Klein | Senior Engineer | Senior ML Engineer | Arjun Nair (TCS-022) | New York |
| TCS-024 | Diego Alvarez | Senior Engineer | Senior Data Engineer | Arjun Nair (TCS-022) | London |
| TCS-025 | Nina Kapoor | Mid-Senior Engineer | RAG Engineer | Hannah Klein (TCS-023) | London |
| TCS-026 | Elias Morgan | Mid-Senior Engineer | Data Platform Engineer | Diego Alvarez (TCS-024) | London |
| TCS-027 | Yara Haddad | Mid-Senior Engineer | Analytics Engineer | Hannah Klein (TCS-023) | Berlin |
| TCS-028 | Owen Patel | Associate Engineer | Junior Data Engineer | Nina Kapoor (TCS-025) | Berlin |
| TCS-029 | Camila Costa | Associate Engineer | AI Associate | Elias Morgan (TCS-026) | Toronto |
| TCS-030 | Theo Nguyen | Intern | Data Science Intern | Arjun Nair (TCS-022) | Toronto |

The table is authoritative for line reporting as of the snapshot date.
