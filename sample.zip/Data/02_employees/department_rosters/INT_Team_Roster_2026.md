# Enterprise Integrations - Staff Roster

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Snapshot: 2026-11-02; department cost center: INT; headcount: 10.

| ID | Employee | Grade | Job title | Reports to | Office |
|---|---|---|---|---|---|
| TCS-051 | Benjamin Carter | Manager | Enterprise Integrations Manager | Eleanor Hart (TCS-001) | New York |
| TCS-052 | Nadia Aziz | Team Lead | Integration Delivery Team Lead | Benjamin Carter (TCS-051) | New York |
| TCS-053 | Thomas van Dijk | Senior Engineer | Senior Integration Architect | Nadia Aziz (TCS-052) | New York |
| TCS-054 | Valentina Rossi | Senior Engineer | Senior Middleware Engineer | Nadia Aziz (TCS-052) | Amsterdam |
| TCS-055 | Aiden Murphy | Mid-Senior Engineer | ERP Integration Engineer | Thomas van Dijk (TCS-053) | Amsterdam |
| TCS-056 | Sara Ibrahim | Mid-Senior Engineer | API Integration Engineer | Valentina Rossi (TCS-054) | Amsterdam |
| TCS-057 | Felipe Rocha | Mid-Senior Engineer | Event Streaming Engineer | Thomas van Dijk (TCS-053) | São Paulo |
| TCS-058 | Chloe Dubois | Associate Engineer | Integration Associate | Aiden Murphy (TCS-055) | São Paulo |
| TCS-059 | Aarav Desai | Associate Engineer | Technical Integration Associate | Sara Ibrahim (TCS-056) | Paris |
| TCS-060 | Ines Moreau | Intern | Integration Intern | Nadia Aziz (TCS-052) | Paris |

The table is authoritative for line reporting as of the snapshot date.
