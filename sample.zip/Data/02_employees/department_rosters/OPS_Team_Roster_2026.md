# Managed IT Operations - Staff Roster

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Snapshot: 2026-11-02; department cost center: OPS; headcount: 10.

| ID | Employee | Grade | Job title | Reports to | Office |
|---|---|---|---|---|---|
| TCS-071 | Alexander Brooks | Manager | Managed IT Operations Manager | Eleanor Hart (TCS-001) | Toronto |
| TCS-072 | Aisha Rahman | Team Lead | Operations Team Lead | Alexander Brooks (TCS-071) | Toronto |
| TCS-073 | David Miller | Senior Engineer | Senior Systems Engineer | Aisha Rahman (TCS-072) | Toronto |
| TCS-074 | Renata Souza | Senior Engineer | Senior Network Engineer | Aisha Rahman (TCS-072) | Austin |
| TCS-075 | Jonas Becker | Mid-Senior Engineer | Service Reliability Engineer | David Miller (TCS-073) | Austin |
| TCS-076 | Tara Singh | Mid-Senior Engineer | Endpoint Management Engineer | Renata Souza (TCS-074) | Austin |
| TCS-077 | Nathan Cole | Mid-Senior Engineer | Monitoring Engineer | David Miller (TCS-073) | Berlin |
| TCS-078 | Bianca Lopes | Associate Engineer | IT Support Associate | Jonas Becker (TCS-075) | Berlin |
| TCS-079 | Eric Foster | Associate Engineer | IT Service Desk Associate | Tara Singh (TCS-076) | London |
| TCS-080 | Ana Costa | Intern | IT Operations Intern | Aisha Rahman (TCS-072) | London |

The table is authoritative for line reporting as of the snapshot date.
