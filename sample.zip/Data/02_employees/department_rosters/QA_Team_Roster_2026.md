# Quality Engineering - Staff Roster

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Snapshot: 2026-11-02; department cost center: QA; headcount: 10.

| ID | Employee | Grade | Job title | Reports to | Office |
|---|---|---|---|---|---|
| TCS-061 | Isabella Clarke | Manager | Quality Engineering Manager | Eleanor Hart (TCS-001) | Toronto |
| TCS-062 | Karthik Raman | Team Lead | Test Automation Team Lead | Isabella Clarke (TCS-061) | Toronto |
| TCS-063 | Beatriz Oliveira | Senior Engineer | Senior Quality Architect | Karthik Raman (TCS-062) | Toronto |
| TCS-064 | Henry Wilson | Senior Engineer | Senior Performance Engineer | Karthik Raman (TCS-062) | São Paulo |
| TCS-065 | Olivia Chen | Mid-Senior Engineer | Automation Engineer | Beatriz Oliveira (TCS-063) | São Paulo |
| TCS-066 | Pablo Santos | Mid-Senior Engineer | Test Engineer | Henry Wilson (TCS-064) | São Paulo |
| TCS-067 | Miriam Becker | Mid-Senior Engineer | Accessibility QA Engineer | Beatriz Oliveira (TCS-063) | London |
| TCS-068 | Finn OConnor | Associate Engineer | Quality Analyst | Olivia Chen (TCS-065) | London |
| TCS-069 | Kiara Shah | Associate Engineer | Junior Test Engineer | Pablo Santos (TCS-066) | New York |
| TCS-070 | Hugo Martins | Intern | QA Intern | Karthik Raman (TCS-062) | New York |

The table is authoritative for line reporting as of the snapshot date.
