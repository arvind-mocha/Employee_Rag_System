# Eleanor Hart | TCS-001

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-001
- Full name: Eleanor Hart
- Corporate email: eleanor_hart@tcs-sandbox.example
- Job title: Managing Director
- Role grade: Manager
- Total professional experience: 14.8 years
- Department: Executive & Corporate Services
- Cost center: CORP
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2018-05-14
- Employment type: Full-time
- Status: Active
- Direct line manager: Board of Directors (external)
- Direct manager employee ID: Board of Directors (external; no employee ID)
- Reporting chain upward: External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
