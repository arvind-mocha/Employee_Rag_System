# Priya Menon | TCS-002

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-002
- Full name: Priya Menon
- Corporate email: priya_menon@tcs-sandbox.example
- Job title: People & Finance Team Lead
- Role grade: Team Lead
- Total professional experience: 9.6 years
- Department: Executive & Corporate Services
- Cost center: CORP
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2021-07-05
- Employment type: Full-time
- Status: Active
- Direct line manager: Eleanor Hart
- Direct manager employee ID: TCS-001
- Reporting chain upward: Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
