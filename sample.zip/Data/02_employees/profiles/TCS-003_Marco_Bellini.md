# Marco Bellini | TCS-003

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-003
- Full name: Marco Bellini
- Corporate email: marco_bellini@tcs-sandbox.example
- Job title: Senior Finance Controller
- Role grade: Senior Engineer
- Total professional experience: 7.4 years
- Department: Executive & Corporate Services
- Cost center: CORP
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2022-02-07
- Employment type: Full-time
- Status: Active
- Direct line manager: Priya Menon
- Direct manager employee ID: TCS-002
- Reporting chain upward: Priya Menon (TCS-002, People & Finance Team Lead) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
