# Sophie Laurent | TCS-004

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-004
- Full name: Sophie Laurent
- Corporate email: sophie_laurent@tcs-sandbox.example
- Job title: Senior HR Business Partner
- Role grade: Senior Engineer
- Total professional experience: 6.3 years
- Department: Executive & Corporate Services
- Cost center: CORP
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2023-05-15
- Employment type: Full-time
- Status: Active
- Direct line manager: Priya Menon
- Direct manager employee ID: TCS-002
- Reporting chain upward: Priya Menon (TCS-002, People & Finance Team Lead) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
