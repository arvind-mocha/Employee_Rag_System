# Daniel Cho | TCS-005

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-005
- Full name: Daniel Cho
- Corporate email: daniel_cho@tcs-sandbox.example
- Job title: Finance Analyst
- Role grade: Mid-Senior Engineer
- Total professional experience: 4.1 years
- Department: Executive & Corporate Services
- Cost center: CORP
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2024-03-04
- Employment type: Full-time
- Status: Active
- Direct line manager: Marco Bellini
- Direct manager employee ID: TCS-003
- Reporting chain upward: Marco Bellini (TCS-003, Senior Finance Controller) -> Priya Menon (TCS-002, People & Finance Team Lead) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
