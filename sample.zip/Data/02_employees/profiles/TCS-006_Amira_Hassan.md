# Amira Hassan | TCS-006

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-006
- Full name: Amira Hassan
- Corporate email: amira_hassan@tcs-sandbox.example
- Job title: Talent Operations Analyst
- Role grade: Mid-Senior Engineer
- Total professional experience: 3.2 years
- Department: Executive & Corporate Services
- Cost center: CORP
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2024-08-12
- Employment type: Full-time
- Status: Active
- Direct line manager: Sophie Laurent
- Direct manager employee ID: TCS-004
- Reporting chain upward: Sophie Laurent (TCS-004, Senior HR Business Partner) -> Priya Menon (TCS-002, People & Finance Team Lead) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
