# Lucia Romero | TCS-008

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-008
- Full name: Lucia Romero
- Corporate email: lucia_romero@tcs-sandbox.example
- Job title: HR Coordinator
- Role grade: Associate Engineer
- Total professional experience: 1.6 years
- Department: Executive & Corporate Services
- Cost center: CORP
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2025-09-08
- Employment type: Full-time
- Status: Active
- Direct line manager: Daniel Cho
- Direct manager employee ID: TCS-005
- Reporting chain upward: Daniel Cho (TCS-005, Finance Analyst) -> Marco Bellini (TCS-003, Senior Finance Controller) -> Priya Menon (TCS-002, People & Finance Team Lead) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
