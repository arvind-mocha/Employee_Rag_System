# Noah Fischer | TCS-009

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-009
- Full name: Noah Fischer
- Corporate email: noah_fischer@tcs-sandbox.example
- Job title: Accounts Assistant
- Role grade: Associate Engineer
- Total professional experience: 1.1 years
- Department: Executive & Corporate Services
- Cost center: CORP
- Office: New York, United States
- Region: Americas
- Time zone: America/New_York
- Hire date: 2025-11-03
- Employment type: Full-time
- Status: Active
- Direct line manager: Amira Hassan
- Direct manager employee ID: TCS-006
- Reporting chain upward: Amira Hassan (TCS-006, Talent Operations Analyst) -> Sophie Laurent (TCS-004, Senior HR Business Partner) -> Priya Menon (TCS-002, People & Finance Team Lead) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
