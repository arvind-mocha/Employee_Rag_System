# Maya Patel | TCS-010

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-010
- Full name: Maya Patel
- Corporate email: maya_patel@tcs-sandbox.example
- Job title: People Operations Intern
- Role grade: Intern
- Total professional experience: 0.4 years
- Department: Executive & Corporate Services
- Cost center: CORP
- Office: New York, United States
- Region: Americas
- Time zone: America/New_York
- Hire date: 2026-07-06
- Employment type: Internship
- Status: Active
- Direct line manager: Priya Menon
- Direct manager employee ID: TCS-002
- Reporting chain upward: Priya Menon (TCS-002, People & Finance Team Lead) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
