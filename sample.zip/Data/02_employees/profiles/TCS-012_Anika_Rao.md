# Anika Rao | TCS-012

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-012
- Full name: Anika Rao
- Corporate email: anika_rao@tcs-sandbox.example
- Job title: Cloud Platform Team Lead
- Role grade: Team Lead
- Total professional experience: 9.6 years
- Department: Cloud Engineering
- Cost center: CLOUD
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2021-07-05
- Employment type: Full-time
- Status: Active
- Direct line manager: Oliver Grant
- Direct manager employee ID: TCS-011
- Reporting chain upward: Oliver Grant (TCS-011, Cloud Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
