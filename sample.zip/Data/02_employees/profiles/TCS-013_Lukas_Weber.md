# Lukas Weber | TCS-013

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-013
- Full name: Lukas Weber
- Corporate email: lukas_weber@tcs-sandbox.example
- Job title: Senior Cloud Architect
- Role grade: Senior Engineer
- Total professional experience: 7.4 years
- Department: Cloud Engineering
- Cost center: CLOUD
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2022-02-07
- Employment type: Full-time
- Status: Active
- Direct line manager: Anika Rao
- Direct manager employee ID: TCS-012
- Reporting chain upward: Anika Rao (TCS-012, Cloud Platform Team Lead) -> Oliver Grant (TCS-011, Cloud Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
