# Emily Brooks | TCS-014

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-014
- Full name: Emily Brooks
- Corporate email: emily_brooks@tcs-sandbox.example
- Job title: Senior Site Reliability Engineer
- Role grade: Senior Engineer
- Total professional experience: 6.3 years
- Department: Cloud Engineering
- Cost center: CLOUD
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2023-05-15
- Employment type: Full-time
- Status: Active
- Direct line manager: Anika Rao
- Direct manager employee ID: TCS-012
- Reporting chain upward: Anika Rao (TCS-012, Cloud Platform Team Lead) -> Oliver Grant (TCS-011, Cloud Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
