# Rohan Iyer | TCS-015

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-015
- Full name: Rohan Iyer
- Corporate email: rohan_iyer@tcs-sandbox.example
- Job title: Cloud Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 4.1 years
- Department: Cloud Engineering
- Cost center: CLOUD
- Office: Berlin, Germany
- Region: Europe
- Time zone: Europe/Berlin
- Hire date: 2024-03-04
- Employment type: Full-time
- Status: Active
- Direct line manager: Lukas Weber
- Direct manager employee ID: TCS-013
- Reporting chain upward: Lukas Weber (TCS-013, Senior Cloud Architect) -> Anika Rao (TCS-012, Cloud Platform Team Lead) -> Oliver Grant (TCS-011, Cloud Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
