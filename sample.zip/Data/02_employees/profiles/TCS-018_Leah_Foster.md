# Leah Foster | TCS-018

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-018
- Full name: Leah Foster
- Corporate email: leah_foster@tcs-sandbox.example
- Job title: Cloud Operations Associate
- Role grade: Associate Engineer
- Total professional experience: 1.6 years
- Department: Cloud Engineering
- Cost center: CLOUD
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2025-09-08
- Employment type: Full-time
- Status: Active
- Direct line manager: Rohan Iyer
- Direct manager employee ID: TCS-015
- Reporting chain upward: Rohan Iyer (TCS-015, Cloud Engineer) -> Lukas Weber (TCS-013, Senior Cloud Architect) -> Anika Rao (TCS-012, Cloud Platform Team Lead) -> Oliver Grant (TCS-011, Cloud Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
