# Ethan Reed | TCS-019

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-019
- Full name: Ethan Reed
- Corporate email: ethan_reed@tcs-sandbox.example
- Job title: Infrastructure Associate
- Role grade: Associate Engineer
- Total professional experience: 1.1 years
- Department: Cloud Engineering
- Cost center: CLOUD
- Office: Austin, United States
- Region: Americas
- Time zone: America/Chicago
- Hire date: 2025-11-03
- Employment type: Full-time
- Status: Active
- Direct line manager: Isabelle Martin
- Direct manager employee ID: TCS-016
- Reporting chain upward: Isabelle Martin (TCS-016, DevOps Engineer) -> Emily Brooks (TCS-014, Senior Site Reliability Engineer) -> Anika Rao (TCS-012, Cloud Platform Team Lead) -> Oliver Grant (TCS-011, Cloud Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
