# Zoya Khan | TCS-020

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-020
- Full name: Zoya Khan
- Corporate email: zoya_khan@tcs-sandbox.example
- Job title: Cloud Engineering Intern
- Role grade: Intern
- Total professional experience: 0.4 years
- Department: Cloud Engineering
- Cost center: CLOUD
- Office: Austin, United States
- Region: Americas
- Time zone: America/Chicago
- Hire date: 2026-07-06
- Employment type: Internship
- Status: Active
- Direct line manager: Anika Rao
- Direct manager employee ID: TCS-012
- Reporting chain upward: Anika Rao (TCS-012, Cloud Platform Team Lead) -> Oliver Grant (TCS-011, Cloud Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
