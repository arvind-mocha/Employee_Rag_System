# Sofia Bennett | TCS-021

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-021
- Full name: Sofia Bennett
- Corporate email: sofia_bennett@tcs-sandbox.example
- Job title: Data & AI Manager
- Role grade: Manager
- Total professional experience: 15.5 years
- Department: Data & AI
- Cost center: DATA
- Office: New York, United States
- Region: Americas
- Time zone: America/New_York
- Hire date: 2018-05-14
- Employment type: Full-time
- Status: Active
- Direct line manager: Eleanor Hart
- Direct manager employee ID: TCS-001
- Reporting chain upward: Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
