# Arjun Nair | TCS-022

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-022
- Full name: Arjun Nair
- Corporate email: arjun_nair@tcs-sandbox.example
- Job title: Data Engineering Team Lead
- Role grade: Team Lead
- Total professional experience: 9.6 years
- Department: Data & AI
- Cost center: DATA
- Office: New York, United States
- Region: Americas
- Time zone: America/New_York
- Hire date: 2021-07-05
- Employment type: Full-time
- Status: Active
- Direct line manager: Sofia Bennett
- Direct manager employee ID: TCS-021
- Reporting chain upward: Sofia Bennett (TCS-021, Data & AI Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
