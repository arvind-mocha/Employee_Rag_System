# Hannah Klein | TCS-023

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-023
- Full name: Hannah Klein
- Corporate email: hannah_klein@tcs-sandbox.example
- Job title: Senior ML Engineer
- Role grade: Senior Engineer
- Total professional experience: 7.4 years
- Department: Data & AI
- Cost center: DATA
- Office: New York, United States
- Region: Americas
- Time zone: America/New_York
- Hire date: 2022-02-07
- Employment type: Full-time
- Status: Active
- Direct line manager: Arjun Nair
- Direct manager employee ID: TCS-022
- Reporting chain upward: Arjun Nair (TCS-022, Data Engineering Team Lead) -> Sofia Bennett (TCS-021, Data & AI Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
