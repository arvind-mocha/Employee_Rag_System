# Diego Alvarez | TCS-024

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-024
- Full name: Diego Alvarez
- Corporate email: diego_alvarez@tcs-sandbox.example
- Job title: Senior Data Engineer
- Role grade: Senior Engineer
- Total professional experience: 6.3 years
- Department: Data & AI
- Cost center: DATA
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2023-05-15
- Employment type: Full-time
- Status: Active
- Direct line manager: Arjun Nair
- Direct manager employee ID: TCS-022
- Reporting chain upward: Arjun Nair (TCS-022, Data Engineering Team Lead) -> Sofia Bennett (TCS-021, Data & AI Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
