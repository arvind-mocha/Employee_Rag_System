# Elias Morgan | TCS-026

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-026
- Full name: Elias Morgan
- Corporate email: elias_morgan@tcs-sandbox.example
- Job title: Data Platform Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 3.2 years
- Department: Data & AI
- Cost center: DATA
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2024-08-12
- Employment type: Full-time
- Status: Active
- Direct line manager: Diego Alvarez
- Direct manager employee ID: TCS-024
- Reporting chain upward: Diego Alvarez (TCS-024, Senior Data Engineer) -> Arjun Nair (TCS-022, Data Engineering Team Lead) -> Sofia Bennett (TCS-021, Data & AI Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
