# Yara Haddad | TCS-027

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-027
- Full name: Yara Haddad
- Corporate email: yara_haddad@tcs-sandbox.example
- Job title: Analytics Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 2.4 years
- Department: Data & AI
- Cost center: DATA
- Office: Berlin, Germany
- Region: Europe
- Time zone: Europe/Berlin
- Hire date: 2025-01-13
- Employment type: Full-time
- Status: Active
- Direct line manager: Hannah Klein
- Direct manager employee ID: TCS-023
- Reporting chain upward: Hannah Klein (TCS-023, Senior ML Engineer) -> Arjun Nair (TCS-022, Data Engineering Team Lead) -> Sofia Bennett (TCS-021, Data & AI Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
