# Owen Patel | TCS-028

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-028
- Full name: Owen Patel
- Corporate email: owen_patel@tcs-sandbox.example
- Job title: Junior Data Engineer
- Role grade: Associate Engineer
- Total professional experience: 1.6 years
- Department: Data & AI
- Cost center: DATA
- Office: Berlin, Germany
- Region: Europe
- Time zone: Europe/Berlin
- Hire date: 2025-09-08
- Employment type: Full-time
- Status: Active
- Direct line manager: Nina Kapoor
- Direct manager employee ID: TCS-025
- Reporting chain upward: Nina Kapoor (TCS-025, RAG Engineer) -> Hannah Klein (TCS-023, Senior ML Engineer) -> Arjun Nair (TCS-022, Data Engineering Team Lead) -> Sofia Bennett (TCS-021, Data & AI Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
