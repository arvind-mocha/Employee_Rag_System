# Camila Costa | TCS-029

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-029
- Full name: Camila Costa
- Corporate email: camila_costa@tcs-sandbox.example
- Job title: AI Associate
- Role grade: Associate Engineer
- Total professional experience: 1.1 years
- Department: Data & AI
- Cost center: DATA
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2025-11-03
- Employment type: Full-time
- Status: Active
- Direct line manager: Elias Morgan
- Direct manager employee ID: TCS-026
- Reporting chain upward: Elias Morgan (TCS-026, Data Platform Engineer) -> Diego Alvarez (TCS-024, Senior Data Engineer) -> Arjun Nair (TCS-022, Data Engineering Team Lead) -> Sofia Bennett (TCS-021, Data & AI Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
