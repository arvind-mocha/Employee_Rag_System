# Theo Nguyen | TCS-030

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-030
- Full name: Theo Nguyen
- Corporate email: theo_nguyen@tcs-sandbox.example
- Job title: Data Science Intern
- Role grade: Intern
- Total professional experience: 0.4 years
- Department: Data & AI
- Cost center: DATA
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2026-07-06
- Employment type: Internship
- Status: Active
- Direct line manager: Arjun Nair
- Direct manager employee ID: TCS-022
- Reporting chain upward: Arjun Nair (TCS-022, Data Engineering Team Lead) -> Sofia Bennett (TCS-021, Data & AI Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
