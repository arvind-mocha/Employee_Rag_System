# Charlotte Evans | TCS-033

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-033
- Full name: Charlotte Evans
- Corporate email: charlotte_evans@tcs-sandbox.example
- Job title: Senior Security Architect
- Role grade: Senior Engineer
- Total professional experience: 7.4 years
- Department: Cybersecurity
- Cost center: CYBER
- Office: Amsterdam, Netherlands
- Region: Europe
- Time zone: Europe/Amsterdam
- Hire date: 2022-02-07
- Employment type: Full-time
- Status: Active
- Direct line manager: Fatima Saeed
- Direct manager employee ID: TCS-032
- Reporting chain upward: Fatima Saeed (TCS-032, Security Operations Team Lead) -> Gabriel Novak (TCS-031, Cybersecurity Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
