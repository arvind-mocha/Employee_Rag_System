# Kenji Watanabe | TCS-034

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-034
- Full name: Kenji Watanabe
- Corporate email: kenji_watanabe@tcs-sandbox.example
- Job title: Senior Incident Responder
- Role grade: Senior Engineer
- Total professional experience: 6.3 years
- Department: Cybersecurity
- Cost center: CYBER
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2023-05-15
- Employment type: Full-time
- Status: Active
- Direct line manager: Fatima Saeed
- Direct manager employee ID: TCS-032
- Reporting chain upward: Fatima Saeed (TCS-032, Security Operations Team Lead) -> Gabriel Novak (TCS-031, Cybersecurity Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
