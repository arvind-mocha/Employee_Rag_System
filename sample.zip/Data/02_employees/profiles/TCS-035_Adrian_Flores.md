# Adrian Flores | TCS-035

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-035
- Full name: Adrian Flores
- Corporate email: adrian_flores@tcs-sandbox.example
- Job title: Cloud Security Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 4.1 years
- Department: Cybersecurity
- Cost center: CYBER
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2024-03-04
- Employment type: Full-time
- Status: Active
- Direct line manager: Charlotte Evans
- Direct manager employee ID: TCS-033
- Reporting chain upward: Charlotte Evans (TCS-033, Senior Security Architect) -> Fatima Saeed (TCS-032, Security Operations Team Lead) -> Gabriel Novak (TCS-031, Cybersecurity Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
