# Elena Petrova | TCS-036

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-036
- Full name: Elena Petrova
- Corporate email: elena_petrova@tcs-sandbox.example
- Job title: Risk & Compliance Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 3.2 years
- Department: Cybersecurity
- Cost center: CYBER
- Office: Austin, United States
- Region: Americas
- Time zone: America/Chicago
- Hire date: 2024-08-12
- Employment type: Full-time
- Status: Active
- Direct line manager: Kenji Watanabe
- Direct manager employee ID: TCS-034
- Reporting chain upward: Kenji Watanabe (TCS-034, Senior Incident Responder) -> Fatima Saeed (TCS-032, Security Operations Team Lead) -> Gabriel Novak (TCS-031, Cybersecurity Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
