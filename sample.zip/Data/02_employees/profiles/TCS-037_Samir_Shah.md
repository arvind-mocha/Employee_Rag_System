# Samir Shah | TCS-037

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-037
- Full name: Samir Shah
- Corporate email: samir_shah@tcs-sandbox.example
- Job title: IAM Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 2.4 years
- Department: Cybersecurity
- Cost center: CYBER
- Office: Austin, United States
- Region: Americas
- Time zone: America/Chicago
- Hire date: 2025-01-13
- Employment type: Full-time
- Status: Active
- Direct line manager: Charlotte Evans
- Direct manager employee ID: TCS-033
- Reporting chain upward: Charlotte Evans (TCS-033, Senior Security Architect) -> Fatima Saeed (TCS-032, Security Operations Team Lead) -> Gabriel Novak (TCS-031, Cybersecurity Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
