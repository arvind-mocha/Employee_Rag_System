# Grace Liu | TCS-038

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-038
- Full name: Grace Liu
- Corporate email: grace_liu@tcs-sandbox.example
- Job title: SOC Analyst
- Role grade: Associate Engineer
- Total professional experience: 1.6 years
- Department: Cybersecurity
- Cost center: CYBER
- Office: Austin, United States
- Region: Americas
- Time zone: America/Chicago
- Hire date: 2025-09-08
- Employment type: Full-time
- Status: Active
- Direct line manager: Adrian Flores
- Direct manager employee ID: TCS-035
- Reporting chain upward: Adrian Flores (TCS-035, Cloud Security Engineer) -> Charlotte Evans (TCS-033, Senior Security Architect) -> Fatima Saeed (TCS-032, Security Operations Team Lead) -> Gabriel Novak (TCS-031, Cybersecurity Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
