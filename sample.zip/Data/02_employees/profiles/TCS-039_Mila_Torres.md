# Mila Torres | TCS-039

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-039
- Full name: Mila Torres
- Corporate email: mila_torres@tcs-sandbox.example
- Job title: Security Operations Associate
- Role grade: Associate Engineer
- Total professional experience: 1.1 years
- Department: Cybersecurity
- Cost center: CYBER
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2025-11-03
- Employment type: Full-time
- Status: Active
- Direct line manager: Elena Petrova
- Direct manager employee ID: TCS-036
- Reporting chain upward: Elena Petrova (TCS-036, Risk & Compliance Engineer) -> Kenji Watanabe (TCS-034, Senior Incident Responder) -> Fatima Saeed (TCS-032, Security Operations Team Lead) -> Gabriel Novak (TCS-031, Cybersecurity Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
