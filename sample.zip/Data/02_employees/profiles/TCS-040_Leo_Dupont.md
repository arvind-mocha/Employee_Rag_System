# Leo Dupont | TCS-040

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-040
- Full name: Leo Dupont
- Corporate email: leo_dupont@tcs-sandbox.example
- Job title: Security Intern
- Role grade: Intern
- Total professional experience: 0.4 years
- Department: Cybersecurity
- Cost center: CYBER
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2026-07-06
- Employment type: Internship
- Status: Active
- Direct line manager: Fatima Saeed
- Direct manager employee ID: TCS-032
- Reporting chain upward: Fatima Saeed (TCS-032, Security Operations Team Lead) -> Gabriel Novak (TCS-031, Cybersecurity Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
