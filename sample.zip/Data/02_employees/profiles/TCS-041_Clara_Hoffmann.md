# Clara Hoffmann | TCS-041

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-041
- Full name: Clara Hoffmann
- Corporate email: clara_hoffmann@tcs-sandbox.example
- Job title: Application Modernization Manager
- Role grade: Manager
- Total professional experience: 15.5 years
- Department: Application Modernization
- Cost center: APP
- Office: Berlin, Germany
- Region: Europe
- Time zone: Europe/Berlin
- Hire date: 2018-05-14
- Employment type: Full-time
- Status: Active
- Direct line manager: Eleanor Hart
- Direct manager employee ID: TCS-001
- Reporting chain upward: Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
