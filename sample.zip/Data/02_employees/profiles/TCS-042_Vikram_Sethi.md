# Vikram Sethi | TCS-042

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-042
- Full name: Vikram Sethi
- Corporate email: vikram_sethi@tcs-sandbox.example
- Job title: Application Development Team Lead
- Role grade: Team Lead
- Total professional experience: 9.6 years
- Department: Application Modernization
- Cost center: APP
- Office: Berlin, Germany
- Region: Europe
- Time zone: Europe/Berlin
- Hire date: 2021-07-05
- Employment type: Full-time
- Status: Active
- Direct line manager: Clara Hoffmann
- Direct manager employee ID: TCS-041
- Reporting chain upward: Clara Hoffmann (TCS-041, Application Modernization Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
