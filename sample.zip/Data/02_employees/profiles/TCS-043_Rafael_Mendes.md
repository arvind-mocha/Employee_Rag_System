# Rafael Mendes | TCS-043

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-043
- Full name: Rafael Mendes
- Corporate email: rafael_mendes@tcs-sandbox.example
- Job title: Senior Backend Engineer
- Role grade: Senior Engineer
- Total professional experience: 7.4 years
- Department: Application Modernization
- Cost center: APP
- Office: Berlin, Germany
- Region: Europe
- Time zone: Europe/Berlin
- Hire date: 2022-02-07
- Employment type: Full-time
- Status: Active
- Direct line manager: Vikram Sethi
- Direct manager employee ID: TCS-042
- Reporting chain upward: Vikram Sethi (TCS-042, Application Development Team Lead) -> Clara Hoffmann (TCS-041, Application Modernization Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
