# Julia Fischer | TCS-044

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-044
- Full name: Julia Fischer
- Corporate email: julia_fischer@tcs-sandbox.example
- Job title: Senior Full-Stack Engineer
- Role grade: Senior Engineer
- Total professional experience: 6.3 years
- Department: Application Modernization
- Cost center: APP
- Office: Austin, United States
- Region: Americas
- Time zone: America/Chicago
- Hire date: 2023-05-15
- Employment type: Full-time
- Status: Active
- Direct line manager: Vikram Sethi
- Direct manager employee ID: TCS-042
- Reporting chain upward: Vikram Sethi (TCS-042, Application Development Team Lead) -> Clara Hoffmann (TCS-041, Application Modernization Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
