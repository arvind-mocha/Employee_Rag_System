# Ava Robinson | TCS-045

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-045
- Full name: Ava Robinson
- Corporate email: ava_robinson@tcs-sandbox.example
- Job title: Java Backend Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 4.1 years
- Department: Application Modernization
- Cost center: APP
- Office: Austin, United States
- Region: Americas
- Time zone: America/Chicago
- Hire date: 2024-03-04
- Employment type: Full-time
- Status: Active
- Direct line manager: Rafael Mendes
- Direct manager employee ID: TCS-043
- Reporting chain upward: Rafael Mendes (TCS-043, Senior Backend Engineer) -> Vikram Sethi (TCS-042, Application Development Team Lead) -> Clara Hoffmann (TCS-041, Application Modernization Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
