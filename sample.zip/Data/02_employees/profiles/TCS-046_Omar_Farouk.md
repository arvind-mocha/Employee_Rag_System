# Omar Farouk | TCS-046

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-046
- Full name: Omar Farouk
- Corporate email: omar_farouk@tcs-sandbox.example
- Job title: Frontend Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 3.2 years
- Department: Application Modernization
- Cost center: APP
- Office: Austin, United States
- Region: Americas
- Time zone: America/Chicago
- Hire date: 2024-08-12
- Employment type: Full-time
- Status: Active
- Direct line manager: Julia Fischer
- Direct manager employee ID: TCS-044
- Reporting chain upward: Julia Fischer (TCS-044, Senior Full-Stack Engineer) -> Vikram Sethi (TCS-042, Application Development Team Lead) -> Clara Hoffmann (TCS-041, Application Modernization Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
