# Liam Collins | TCS-048

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-048
- Full name: Liam Collins
- Corporate email: liam_collins@tcs-sandbox.example
- Job title: Application Engineer
- Role grade: Associate Engineer
- Total professional experience: 1.6 years
- Department: Application Modernization
- Cost center: APP
- Office: Paris, France
- Region: Europe
- Time zone: Europe/Paris
- Hire date: 2025-09-08
- Employment type: Full-time
- Status: Active
- Direct line manager: Ava Robinson
- Direct manager employee ID: TCS-045
- Reporting chain upward: Ava Robinson (TCS-045, Java Backend Engineer) -> Rafael Mendes (TCS-043, Senior Backend Engineer) -> Vikram Sethi (TCS-042, Application Development Team Lead) -> Clara Hoffmann (TCS-041, Application Modernization Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
