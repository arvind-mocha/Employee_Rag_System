# Nora Schmidt | TCS-049

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-049
- Full name: Nora Schmidt
- Corporate email: nora_schmidt@tcs-sandbox.example
- Job title: Software Associate
- Role grade: Associate Engineer
- Total professional experience: 1.1 years
- Department: Application Modernization
- Cost center: APP
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2025-11-03
- Employment type: Full-time
- Status: Active
- Direct line manager: Omar Farouk
- Direct manager employee ID: TCS-046
- Reporting chain upward: Omar Farouk (TCS-046, Frontend Engineer) -> Julia Fischer (TCS-044, Senior Full-Stack Engineer) -> Vikram Sethi (TCS-042, Application Development Team Lead) -> Clara Hoffmann (TCS-041, Application Modernization Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
