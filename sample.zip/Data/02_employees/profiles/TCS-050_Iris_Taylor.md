# Iris Taylor | TCS-050

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-050
- Full name: Iris Taylor
- Corporate email: iris_taylor@tcs-sandbox.example
- Job title: Software Engineering Intern
- Role grade: Intern
- Total professional experience: 0.4 years
- Department: Application Modernization
- Cost center: APP
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2026-07-06
- Employment type: Internship
- Status: Active
- Direct line manager: Vikram Sethi
- Direct manager employee ID: TCS-042
- Reporting chain upward: Vikram Sethi (TCS-042, Application Development Team Lead) -> Clara Hoffmann (TCS-041, Application Modernization Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
