# Nadia Aziz | TCS-052

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-052
- Full name: Nadia Aziz
- Corporate email: nadia_aziz@tcs-sandbox.example
- Job title: Integration Delivery Team Lead
- Role grade: Team Lead
- Total professional experience: 9.6 years
- Department: Enterprise Integrations
- Cost center: INT
- Office: New York, United States
- Region: Americas
- Time zone: America/New_York
- Hire date: 2021-07-05
- Employment type: Full-time
- Status: Active
- Direct line manager: Benjamin Carter
- Direct manager employee ID: TCS-051
- Reporting chain upward: Benjamin Carter (TCS-051, Enterprise Integrations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
