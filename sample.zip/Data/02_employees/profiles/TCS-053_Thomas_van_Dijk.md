# Thomas van Dijk | TCS-053

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-053
- Full name: Thomas van Dijk
- Corporate email: thomas_van_dijk@tcs-sandbox.example
- Job title: Senior Integration Architect
- Role grade: Senior Engineer
- Total professional experience: 7.4 years
- Department: Enterprise Integrations
- Cost center: INT
- Office: New York, United States
- Region: Americas
- Time zone: America/New_York
- Hire date: 2022-02-07
- Employment type: Full-time
- Status: Active
- Direct line manager: Nadia Aziz
- Direct manager employee ID: TCS-052
- Reporting chain upward: Nadia Aziz (TCS-052, Integration Delivery Team Lead) -> Benjamin Carter (TCS-051, Enterprise Integrations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
