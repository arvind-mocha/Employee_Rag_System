# Valentina Rossi | TCS-054

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-054
- Full name: Valentina Rossi
- Corporate email: valentina_rossi@tcs-sandbox.example
- Job title: Senior Middleware Engineer
- Role grade: Senior Engineer
- Total professional experience: 6.3 years
- Department: Enterprise Integrations
- Cost center: INT
- Office: Amsterdam, Netherlands
- Region: Europe
- Time zone: Europe/Amsterdam
- Hire date: 2023-05-15
- Employment type: Full-time
- Status: Active
- Direct line manager: Nadia Aziz
- Direct manager employee ID: TCS-052
- Reporting chain upward: Nadia Aziz (TCS-052, Integration Delivery Team Lead) -> Benjamin Carter (TCS-051, Enterprise Integrations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
