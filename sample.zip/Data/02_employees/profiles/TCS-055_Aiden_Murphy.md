# Aiden Murphy | TCS-055

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-055
- Full name: Aiden Murphy
- Corporate email: aiden_murphy@tcs-sandbox.example
- Job title: ERP Integration Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 4.1 years
- Department: Enterprise Integrations
- Cost center: INT
- Office: Amsterdam, Netherlands
- Region: Europe
- Time zone: Europe/Amsterdam
- Hire date: 2024-03-04
- Employment type: Full-time
- Status: Active
- Direct line manager: Thomas van Dijk
- Direct manager employee ID: TCS-053
- Reporting chain upward: Thomas van Dijk (TCS-053, Senior Integration Architect) -> Nadia Aziz (TCS-052, Integration Delivery Team Lead) -> Benjamin Carter (TCS-051, Enterprise Integrations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
