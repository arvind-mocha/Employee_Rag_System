# Sara Ibrahim | TCS-056

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-056
- Full name: Sara Ibrahim
- Corporate email: sara_ibrahim@tcs-sandbox.example
- Job title: API Integration Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 3.2 years
- Department: Enterprise Integrations
- Cost center: INT
- Office: Amsterdam, Netherlands
- Region: Europe
- Time zone: Europe/Amsterdam
- Hire date: 2024-08-12
- Employment type: Full-time
- Status: Active
- Direct line manager: Valentina Rossi
- Direct manager employee ID: TCS-054
- Reporting chain upward: Valentina Rossi (TCS-054, Senior Middleware Engineer) -> Nadia Aziz (TCS-052, Integration Delivery Team Lead) -> Benjamin Carter (TCS-051, Enterprise Integrations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
