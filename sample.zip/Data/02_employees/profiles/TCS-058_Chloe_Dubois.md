# Chloe Dubois | TCS-058

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-058
- Full name: Chloe Dubois
- Corporate email: chloe_dubois@tcs-sandbox.example
- Job title: Integration Associate
- Role grade: Associate Engineer
- Total professional experience: 1.6 years
- Department: Enterprise Integrations
- Cost center: INT
- Office: São Paulo, Brazil
- Region: Americas
- Time zone: America/Sao_Paulo
- Hire date: 2025-09-08
- Employment type: Full-time
- Status: Active
- Direct line manager: Aiden Murphy
- Direct manager employee ID: TCS-055
- Reporting chain upward: Aiden Murphy (TCS-055, ERP Integration Engineer) -> Thomas van Dijk (TCS-053, Senior Integration Architect) -> Nadia Aziz (TCS-052, Integration Delivery Team Lead) -> Benjamin Carter (TCS-051, Enterprise Integrations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
