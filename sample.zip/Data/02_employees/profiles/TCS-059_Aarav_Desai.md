# Aarav Desai | TCS-059

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-059
- Full name: Aarav Desai
- Corporate email: aarav_desai@tcs-sandbox.example
- Job title: Technical Integration Associate
- Role grade: Associate Engineer
- Total professional experience: 1.1 years
- Department: Enterprise Integrations
- Cost center: INT
- Office: Paris, France
- Region: Europe
- Time zone: Europe/Paris
- Hire date: 2025-11-03
- Employment type: Full-time
- Status: Active
- Direct line manager: Sara Ibrahim
- Direct manager employee ID: TCS-056
- Reporting chain upward: Sara Ibrahim (TCS-056, API Integration Engineer) -> Valentina Rossi (TCS-054, Senior Middleware Engineer) -> Nadia Aziz (TCS-052, Integration Delivery Team Lead) -> Benjamin Carter (TCS-051, Enterprise Integrations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
