# Ines Moreau | TCS-060

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-060
- Full name: Ines Moreau
- Corporate email: ines_moreau@tcs-sandbox.example
- Job title: Integration Intern
- Role grade: Intern
- Total professional experience: 0.4 years
- Department: Enterprise Integrations
- Cost center: INT
- Office: Paris, France
- Region: Europe
- Time zone: Europe/Paris
- Hire date: 2026-07-06
- Employment type: Internship
- Status: Active
- Direct line manager: Nadia Aziz
- Direct manager employee ID: TCS-052
- Reporting chain upward: Nadia Aziz (TCS-052, Integration Delivery Team Lead) -> Benjamin Carter (TCS-051, Enterprise Integrations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
