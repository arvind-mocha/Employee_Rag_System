# Karthik Raman | TCS-062

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-062
- Full name: Karthik Raman
- Corporate email: karthik_raman@tcs-sandbox.example
- Job title: Test Automation Team Lead
- Role grade: Team Lead
- Total professional experience: 9.6 years
- Department: Quality Engineering
- Cost center: QA
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2021-07-05
- Employment type: Full-time
- Status: Active
- Direct line manager: Isabella Clarke
- Direct manager employee ID: TCS-061
- Reporting chain upward: Isabella Clarke (TCS-061, Quality Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
