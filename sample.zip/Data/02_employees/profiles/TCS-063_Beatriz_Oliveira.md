# Beatriz Oliveira | TCS-063

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-063
- Full name: Beatriz Oliveira
- Corporate email: beatriz_oliveira@tcs-sandbox.example
- Job title: Senior Quality Architect
- Role grade: Senior Engineer
- Total professional experience: 7.4 years
- Department: Quality Engineering
- Cost center: QA
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2022-02-07
- Employment type: Full-time
- Status: Active
- Direct line manager: Karthik Raman
- Direct manager employee ID: TCS-062
- Reporting chain upward: Karthik Raman (TCS-062, Test Automation Team Lead) -> Isabella Clarke (TCS-061, Quality Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
