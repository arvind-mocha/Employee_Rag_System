# Olivia Chen | TCS-065

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-065
- Full name: Olivia Chen
- Corporate email: olivia_chen@tcs-sandbox.example
- Job title: Automation Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 4.1 years
- Department: Quality Engineering
- Cost center: QA
- Office: São Paulo, Brazil
- Region: Americas
- Time zone: America/Sao_Paulo
- Hire date: 2024-03-04
- Employment type: Full-time
- Status: Active
- Direct line manager: Beatriz Oliveira
- Direct manager employee ID: TCS-063
- Reporting chain upward: Beatriz Oliveira (TCS-063, Senior Quality Architect) -> Karthik Raman (TCS-062, Test Automation Team Lead) -> Isabella Clarke (TCS-061, Quality Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
