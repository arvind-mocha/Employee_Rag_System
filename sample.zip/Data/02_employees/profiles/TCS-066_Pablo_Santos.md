# Pablo Santos | TCS-066

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-066
- Full name: Pablo Santos
- Corporate email: pablo_santos@tcs-sandbox.example
- Job title: Test Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 3.2 years
- Department: Quality Engineering
- Cost center: QA
- Office: São Paulo, Brazil
- Region: Americas
- Time zone: America/Sao_Paulo
- Hire date: 2024-08-12
- Employment type: Full-time
- Status: Active
- Direct line manager: Henry Wilson
- Direct manager employee ID: TCS-064
- Reporting chain upward: Henry Wilson (TCS-064, Senior Performance Engineer) -> Karthik Raman (TCS-062, Test Automation Team Lead) -> Isabella Clarke (TCS-061, Quality Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
