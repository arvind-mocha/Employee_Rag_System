# Miriam Becker | TCS-067

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-067
- Full name: Miriam Becker
- Corporate email: miriam_becker@tcs-sandbox.example
- Job title: Accessibility QA Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 2.4 years
- Department: Quality Engineering
- Cost center: QA
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2025-01-13
- Employment type: Full-time
- Status: Active
- Direct line manager: Beatriz Oliveira
- Direct manager employee ID: TCS-063
- Reporting chain upward: Beatriz Oliveira (TCS-063, Senior Quality Architect) -> Karthik Raman (TCS-062, Test Automation Team Lead) -> Isabella Clarke (TCS-061, Quality Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
