# Finn OConnor | TCS-068

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-068
- Full name: Finn OConnor
- Corporate email: finn_oconnor@tcs-sandbox.example
- Job title: Quality Analyst
- Role grade: Associate Engineer
- Total professional experience: 1.6 years
- Department: Quality Engineering
- Cost center: QA
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2025-09-08
- Employment type: Full-time
- Status: Active
- Direct line manager: Olivia Chen
- Direct manager employee ID: TCS-065
- Reporting chain upward: Olivia Chen (TCS-065, Automation Engineer) -> Beatriz Oliveira (TCS-063, Senior Quality Architect) -> Karthik Raman (TCS-062, Test Automation Team Lead) -> Isabella Clarke (TCS-061, Quality Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
