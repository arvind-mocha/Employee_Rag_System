# Kiara Shah | TCS-069

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-069
- Full name: Kiara Shah
- Corporate email: kiara_shah@tcs-sandbox.example
- Job title: Junior Test Engineer
- Role grade: Associate Engineer
- Total professional experience: 1.1 years
- Department: Quality Engineering
- Cost center: QA
- Office: New York, United States
- Region: Americas
- Time zone: America/New_York
- Hire date: 2025-11-03
- Employment type: Full-time
- Status: Active
- Direct line manager: Pablo Santos
- Direct manager employee ID: TCS-066
- Reporting chain upward: Pablo Santos (TCS-066, Test Engineer) -> Henry Wilson (TCS-064, Senior Performance Engineer) -> Karthik Raman (TCS-062, Test Automation Team Lead) -> Isabella Clarke (TCS-061, Quality Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
