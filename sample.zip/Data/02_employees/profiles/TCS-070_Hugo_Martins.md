# Hugo Martins | TCS-070

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-070
- Full name: Hugo Martins
- Corporate email: hugo_martins@tcs-sandbox.example
- Job title: QA Intern
- Role grade: Intern
- Total professional experience: 0.4 years
- Department: Quality Engineering
- Cost center: QA
- Office: New York, United States
- Region: Americas
- Time zone: America/New_York
- Hire date: 2026-07-06
- Employment type: Internship
- Status: Active
- Direct line manager: Karthik Raman
- Direct manager employee ID: TCS-062
- Reporting chain upward: Karthik Raman (TCS-062, Test Automation Team Lead) -> Isabella Clarke (TCS-061, Quality Engineering Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
