# Alexander Brooks | TCS-071

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-071
- Full name: Alexander Brooks
- Corporate email: alexander_brooks@tcs-sandbox.example
- Job title: Managed IT Operations Manager
- Role grade: Manager
- Total professional experience: 15.5 years
- Department: Managed IT Operations
- Cost center: OPS
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2018-05-14
- Employment type: Full-time
- Status: Active
- Direct line manager: Eleanor Hart
- Direct manager employee ID: TCS-001
- Reporting chain upward: Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
