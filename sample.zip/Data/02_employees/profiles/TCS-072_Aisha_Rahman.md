# Aisha Rahman | TCS-072

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-072
- Full name: Aisha Rahman
- Corporate email: aisha_rahman@tcs-sandbox.example
- Job title: Operations Team Lead
- Role grade: Team Lead
- Total professional experience: 9.6 years
- Department: Managed IT Operations
- Cost center: OPS
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2021-07-05
- Employment type: Full-time
- Status: Active
- Direct line manager: Alexander Brooks
- Direct manager employee ID: TCS-071
- Reporting chain upward: Alexander Brooks (TCS-071, Managed IT Operations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
