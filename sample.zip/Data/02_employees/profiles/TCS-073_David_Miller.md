# David Miller | TCS-073

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-073
- Full name: David Miller
- Corporate email: david_miller@tcs-sandbox.example
- Job title: Senior Systems Engineer
- Role grade: Senior Engineer
- Total professional experience: 7.4 years
- Department: Managed IT Operations
- Cost center: OPS
- Office: Toronto, Canada
- Region: Americas
- Time zone: America/Toronto
- Hire date: 2022-02-07
- Employment type: Full-time
- Status: Active
- Direct line manager: Aisha Rahman
- Direct manager employee ID: TCS-072
- Reporting chain upward: Aisha Rahman (TCS-072, Operations Team Lead) -> Alexander Brooks (TCS-071, Managed IT Operations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
