# Renata Souza | TCS-074

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-074
- Full name: Renata Souza
- Corporate email: renata_souza@tcs-sandbox.example
- Job title: Senior Network Engineer
- Role grade: Senior Engineer
- Total professional experience: 6.3 years
- Department: Managed IT Operations
- Cost center: OPS
- Office: Austin, United States
- Region: Americas
- Time zone: America/Chicago
- Hire date: 2023-05-15
- Employment type: Full-time
- Status: Active
- Direct line manager: Aisha Rahman
- Direct manager employee ID: TCS-072
- Reporting chain upward: Aisha Rahman (TCS-072, Operations Team Lead) -> Alexander Brooks (TCS-071, Managed IT Operations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
