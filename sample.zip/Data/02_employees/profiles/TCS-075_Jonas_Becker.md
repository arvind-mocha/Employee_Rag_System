# Jonas Becker | TCS-075

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-075
- Full name: Jonas Becker
- Corporate email: jonas_becker@tcs-sandbox.example
- Job title: Service Reliability Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 4.1 years
- Department: Managed IT Operations
- Cost center: OPS
- Office: Austin, United States
- Region: Americas
- Time zone: America/Chicago
- Hire date: 2024-03-04
- Employment type: Full-time
- Status: Active
- Direct line manager: David Miller
- Direct manager employee ID: TCS-073
- Reporting chain upward: David Miller (TCS-073, Senior Systems Engineer) -> Aisha Rahman (TCS-072, Operations Team Lead) -> Alexander Brooks (TCS-071, Managed IT Operations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
