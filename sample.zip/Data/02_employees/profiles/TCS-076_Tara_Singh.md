# Tara Singh | TCS-076

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-076
- Full name: Tara Singh
- Corporate email: tara_singh@tcs-sandbox.example
- Job title: Endpoint Management Engineer
- Role grade: Mid-Senior Engineer
- Total professional experience: 3.2 years
- Department: Managed IT Operations
- Cost center: OPS
- Office: Austin, United States
- Region: Americas
- Time zone: America/Chicago
- Hire date: 2024-08-12
- Employment type: Full-time
- Status: Active
- Direct line manager: Renata Souza
- Direct manager employee ID: TCS-074
- Reporting chain upward: Renata Souza (TCS-074, Senior Network Engineer) -> Aisha Rahman (TCS-072, Operations Team Lead) -> Alexander Brooks (TCS-071, Managed IT Operations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
