# Bianca Lopes | TCS-078

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-078
- Full name: Bianca Lopes
- Corporate email: bianca_lopes@tcs-sandbox.example
- Job title: IT Support Associate
- Role grade: Associate Engineer
- Total professional experience: 1.6 years
- Department: Managed IT Operations
- Cost center: OPS
- Office: Berlin, Germany
- Region: Europe
- Time zone: Europe/Berlin
- Hire date: 2025-09-08
- Employment type: Full-time
- Status: Active
- Direct line manager: Jonas Becker
- Direct manager employee ID: TCS-075
- Reporting chain upward: Jonas Becker (TCS-075, Service Reliability Engineer) -> David Miller (TCS-073, Senior Systems Engineer) -> Aisha Rahman (TCS-072, Operations Team Lead) -> Alexander Brooks (TCS-071, Managed IT Operations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
