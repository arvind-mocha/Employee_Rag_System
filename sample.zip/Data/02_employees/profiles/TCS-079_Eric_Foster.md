# Eric Foster | TCS-079

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-079
- Full name: Eric Foster
- Corporate email: eric_foster@tcs-sandbox.example
- Job title: IT Service Desk Associate
- Role grade: Associate Engineer
- Total professional experience: 1.1 years
- Department: Managed IT Operations
- Cost center: OPS
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2025-11-03
- Employment type: Full-time
- Status: Active
- Direct line manager: Tara Singh
- Direct manager employee ID: TCS-076
- Reporting chain upward: Tara Singh (TCS-076, Endpoint Management Engineer) -> Renata Souza (TCS-074, Senior Network Engineer) -> Aisha Rahman (TCS-072, Operations Team Lead) -> Alexander Brooks (TCS-071, Managed IT Operations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
