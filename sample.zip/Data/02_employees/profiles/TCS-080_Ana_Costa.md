# Ana Costa | TCS-080

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES

Document type: Employee profile
Effective snapshot: 2026-11-02
Classification: INTERNAL - SYNTHETIC

- Employee ID: TCS-080
- Full name: Ana Costa
- Corporate email: ana_costa@tcs-sandbox.example
- Job title: IT Operations Intern
- Role grade: Intern
- Total professional experience: 0.4 years
- Department: Managed IT Operations
- Cost center: OPS
- Office: London, United Kingdom
- Region: Europe
- Time zone: Europe/London
- Hire date: 2026-07-06
- Employment type: Internship
- Status: Active
- Direct line manager: Aisha Rahman
- Direct manager employee ID: TCS-072
- Reporting chain upward: Aisha Rahman (TCS-072, Operations Team Lead) -> Alexander Brooks (TCS-071, Managed IT Operations Manager) -> Eleanor Hart (TCS-001, Managing Director) -> External Board of Directors

Note: all identities are fictional. Reporting is line management, not necessarily project ownership.
