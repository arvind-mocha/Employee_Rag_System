# Project Brief - Warehouse Cloud Migration

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES
Document ID: PRJ-BLU-112
Snapshot: 2026-11-02
Classification: CONFIDENTIAL - SYNTHETIC

Client: BlueHarbor Logistics (CL-003)
Client region: Europe
Account owner: Oliver Grant (TCS-011)
Service lines: Cloud Engineering, Managed IT Operations
Project milestone target: 2026-11-20
Delivery scope: Migration of warehouse scheduling and tracking systems with disaster recovery across two regions.
Key delivery metric: 99.95% availability for tracking portal
Applicable client incident handling: OPS-003 v2.0 effective 2026-06-01.
Data requirements: GOV-004; Security: IT-SEC-002.

This is a fictional project entry with no actual customer data.
