# Project Brief - Energy Forecast Assistant

FICTIONAL TEST DATA | TCS SANDBOX | NOT TATA CONSULTANCY SERVICES
Document ID: PRJ-VEL-422
Snapshot: 2026-11-02
Classification: CONFIDENTIAL - SYNTHETIC

Client: Vela Energy (CL-005)
Client region: Europe
Account owner: Arjun Nair (TCS-022)
Service lines: Data & AI, Cloud Engineering
Project milestone target: 2027-01-29
Delivery scope: RAG-enabled field engineering knowledge assistant with citations and offline evaluation.
Key delivery metric: 85% human-approved response usefulness on curated evaluation set
Applicable client incident handling: OPS-003 v2.0 effective 2026-06-01.
Data requirements: GOV-004; Security: IT-SEC-002.

This is a fictional project entry with no actual customer data.
